
import './App.css';
import Faq from './components/Faq';
import './components/Faq.css';
import './components/popular.css';
import Popularques from './components/Popularques';


function App() {
  return (
    <>
    <Faq/>

    </>
  );
}

export default App;
