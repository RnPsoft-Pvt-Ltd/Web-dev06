import React from 'react'

export default function Benef() {
  return (
    <div>
      
    </div>
  )
}
