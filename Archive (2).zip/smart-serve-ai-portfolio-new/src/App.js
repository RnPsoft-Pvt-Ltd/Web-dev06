import './App.css';
import Sidebar from './Components/Sidebar';
import Ticket from './Components/Ticket';

function App() {
  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content">
        <Ticket/>
      </div>
    </div>
  );
}

export default App;
